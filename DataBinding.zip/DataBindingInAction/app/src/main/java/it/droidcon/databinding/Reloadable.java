package it.droidcon.databinding;

public interface Reloadable {
    String getErrorMessage();

    void reload();
}
