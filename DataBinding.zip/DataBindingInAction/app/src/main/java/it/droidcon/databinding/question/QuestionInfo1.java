package it.droidcon.databinding.question;

public class QuestionInfo1 {
    public String answer = "";

    public int countdown = 10;

    public int decrementCountdown() {
        return --countdown;
    }
}
