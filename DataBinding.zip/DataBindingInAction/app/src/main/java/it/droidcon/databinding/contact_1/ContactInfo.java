package it.droidcon.databinding.contact_1;

public class ContactInfo {
    public String message;

    public boolean messageAvailable;
}
