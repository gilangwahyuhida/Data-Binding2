# Data Binding in action
Demo project for Android Data Binding in Action using MVVM pattern, slides are available on [slideshare](//www.slideshare.net/fabio_collini/data-binding-in-action-using-mvvm-pattern)
